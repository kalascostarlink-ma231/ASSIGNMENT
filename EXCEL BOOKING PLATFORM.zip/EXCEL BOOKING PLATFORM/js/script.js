'use strict';

/* =========================================================
   EXCEL BOOKING CENTER — APPLICATION SCRIPT
   Sections: Data, State, Utilities, Rendering, Validation,
   Live Summary, Booking Submission, My Bookings, Contact Form,
   Navigation, Animations, Init
   ========================================================= */

/* ---------- Data ---------- */
// Master list of services offered. Rendered dynamically — never hard-coded in HTML.
const services = [
  {
    id: 1,
    name: 'Hair Styling & Braiding',
    description: 'Expert braiding, weaving and styling tailored to your look.',
    duration: 90,
    price: 25,
    category: 'beauty',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"><path d="M4 5h16v3H4z"/><path d="M6.5 8v11M10 8v11M13.5 8v11M17 8v11"/></svg>',
  },
  {
    id: 2,
    name: 'Barbing & Grooming',
    description: 'Sharp fades, clean lines and beard grooming for gentlemen.',
    duration: 45,
    price: 10,
    category: 'grooming',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="6" r="2.2"/><circle cx="6" cy="18" r="2.2"/><path d="M7.8 7.6 19 17M7.8 16.4 19 7"/></svg>',
  },
  {
    id: 3,
    name: 'Manicure & Pedicure',
    description: 'Complete nail care leaving your hands and feet refreshed.',
    duration: 60,
    price: 20,
    category: 'beauty',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21c-1.5 0-2.5-1.2-2.5-3 0-3 1-6 1-9a2.5 2.5 0 0 1 5 0c0 3 1 6 1 9 0 1.8-1 3-2.5 3z"/><path d="M12 3.5V2M9.5 4 8.8 2.7M14.5 4l.7-1.3"/></svg>',
  },
  {
    id: 4,
    name: 'Facial Treatment',
    description: 'Deep-cleansing facial to rejuvenate and brighten your skin.',
    duration: 60,
    price: 30,
    category: 'wellness',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="13" r="7"/><path d="M8.5 12h.01M13.5 12h.01M8.5 15.5c1 1 4 1 5 0"/><path d="M19 4l.8 1.8 1.7.7-1.7.8L19 9l-.8-1.7-1.7-.8 1.7-.7z"/></svg>',
  },
  {
    id: 5,
    name: 'Massage Therapy',
    description: 'Relaxing full-body massage to relieve stress and tension.',
    duration: 75,
    price: 40,
    category: 'wellness',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9c2 0 2-3 4-3s2 3 4 3 2-3 4-3 2 3 4 3"/><path d="M3 15c2 0 2-3 4-3s2 3 4 3 2-3 4-3 2 3 4 3"/></svg>',
  },
  {
    id: 6,
    name: 'Makeup Session',
    description: 'Professional makeup application for any occasion.',
    duration: 60,
    price: 35,
    category: 'beauty',
    icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M10 3h4l1 4h-6z"/><path d="M9 7h6v9a3 3 0 0 1-3 3 3 3 0 0 1-3-3z"/></svg>',
  },
];

/* ---------- State ---------- */
// All bookings made during the current session (in-memory only).
const bookings = [];
let selectedTimeSlot = null;

/* ---------- Utilities ---------- */

// Builds the list of bookable time slots from 9:00 AM to 5:00 PM in 30-minute steps.
function generateTimeSlots() {
  const slots = [];
  let hour = 9;
  let minute = 0;
  while (hour < 17 || (hour === 17 && minute === 0)) {
    const period = hour < 12 ? 'AM' : 'PM';
    const displayHour = hour > 12 ? hour - 12 : hour;
    const displayMinute = minute === 0 ? '00' : minute;
    slots.push(`${displayHour}:${displayMinute} ${period}`);
    minute += 30;
    if (minute === 60) {
      minute = 0;
      hour += 1;
    }
  }
  return slots;
}

const TIME_SLOTS = generateTimeSlots();

// Formats a duration in minutes as a human-readable string, e.g. "1 hr 30 min".
function formatDuration(minutes) {
  const hrs = Math.floor(minutes / 60);
  const mins = minutes % 60;
  if (hrs === 0) return `${mins} min`;
  if (mins === 0) return `${hrs} hr`;
  return `${hrs} hr ${mins} min`;
}

// Formats a YYYY-MM-DD date string as a readable date, e.g. "Jul 23, 2026".
function formatDate(isoDate) {
  if (!isoDate) return '';
  const [year, month, day] = isoDate.split('-').map(Number);
  const date = new Date(year, month - 1, day);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Generates a booking reference like EBC-2026-0417.
function generateBookingReference() {
  const year = new Date().getFullYear();
  const randomPart = Math.floor(1000 + Math.random() * 9000);
  return `EBC-${year}-${randomPart}`;
}

// Shows a temporary toast notification.
function showToast(message) {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => toast.classList.remove('show'), 3200);
}

/* ---------- Rendering: Services ---------- */

// Renders service cards into the grid, optionally filtered by category.
function renderServices(filter = 'all') {
  const grid = document.getElementById('serviceGrid');
  grid.innerHTML = '';

  services.forEach((service) => {
    const card = document.createElement('div');
    card.className = 'service-card';
    card.dataset.category = service.category;
    if (filter !== 'all' && service.category !== filter) {
      card.classList.add('is-hidden');
    }

    card.innerHTML = `
      <div class="service-icon-badge">${service.icon}</div>
      <span class="category-tag">${service.category}</span>
      <h3>${service.name}</h3>
      <p>${service.description}</p>
      <div class="service-meta">
        <span class="duration">${formatDuration(service.duration)}</span>
        <span class="price">$${service.price}</span>
      </div>
      <button type="button" class="btn btn-secondary select-service-btn" data-id="${service.id}">Select</button>
    `;
    grid.appendChild(card);
  });
}

// Populates the service <select> dropdown from the services array.
function populateServiceDropdown() {
  const select = document.getElementById('serviceSelect');
  services.forEach((service) => {
    const option = document.createElement('option');
    option.value = service.id;
    option.textContent = `${service.name} — $${service.price} (${formatDuration(service.duration)})`;
    select.appendChild(option);
  });
}

// Wires up the category filter buttons.
function initFilterBar() {
  const filterBar = document.getElementById('filterBar');
  filterBar.addEventListener('click', (event) => {
    const btn = event.target.closest('.filter-btn');
    if (!btn) return;
    filterBar.querySelectorAll('.filter-btn').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    renderServices(btn.dataset.category);
  });
}

// Clicking "Select" on a card jumps to the booking form with that service pre-chosen.
function initServiceSelection() {
  document.getElementById('serviceGrid').addEventListener('click', (event) => {
    const btn = event.target.closest('.select-service-btn');
    if (!btn) return;
    const select = document.getElementById('serviceSelect');
    select.value = btn.dataset.id;
    updateSummary();
    document.getElementById('book').scrollIntoView({ behavior: 'smooth' });
  });
}

/* ---------- Rendering: Time Slots ---------- */

// Renders the time slot buttons, disabling any already booked for the selected date/service.
function renderTimeSlots() {
  const container = document.getElementById('timeSlotGrid');
  const dateValue = document.getElementById('bookingDate').value;
  container.innerHTML = '';

  TIME_SLOTS.forEach((slot) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'time-slot-btn';
    button.textContent = slot;

    const isTaken = dateValue && bookings.some((b) => b.date === dateValue && b.time === slot);
    if (isTaken) {
      button.classList.add('taken');
      button.disabled = true;
    }
    if (selectedTimeSlot === slot && !isTaken) {
      button.classList.add('selected');
    }

    button.addEventListener('click', () => {
      selectedTimeSlot = slot;
      document.getElementById('timeSlotInput').value = slot;
      renderTimeSlots();
      validateField('timeSlot');
      updateSummary();
    });

    container.appendChild(button);
  });
}

/* ---------- Validation ---------- */

// Sets the visual valid/invalid state and error message for a field.
function setFieldState(inputEl, errorEl, isValid, message) {
  if (isValid) {
    inputEl.classList.add('valid');
    inputEl.classList.remove('invalid');
    errorEl.textContent = '';
  } else {
    inputEl.classList.add('invalid');
    inputEl.classList.remove('valid');
    errorEl.textContent = message;
  }
  return isValid;
}

// Validates a single named field and returns true/false. Also updates its UI state.
function validateField(fieldName) {
  switch (fieldName) {
    case 'fullName': {
      const input = document.getElementById('fullName');
      const errorEl = document.getElementById('err-fullName');
      const value = input.value.trim();
      const isValid = /^[A-Za-z\s'-]{3,}$/.test(value);
      return setFieldState(input, errorEl, isValid, 'Name must be at least 3 letters (letters only).');
    }
    case 'phone': {
      const input = document.getElementById('phone');
      const errorEl = document.getElementById('err-phone');
      const value = input.value.trim();
      const isValid = /^(?:\+231|0)\d{9}$/.test(value);
      return setFieldState(input, errorEl, isValid, 'Enter a valid Liberian number, e.g. 0886692124 or +231886692124.');
    }
    case 'email': {
      const input = document.getElementById('email');
      const errorEl = document.getElementById('err-email');
      const value = input.value.trim();
      const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
      return setFieldState(input, errorEl, isValid, 'Enter a valid email address.');
    }
    case 'serviceSelect': {
      const input = document.getElementById('serviceSelect');
      const errorEl = document.getElementById('err-serviceSelect');
      const isValid = input.value !== '';
      return setFieldState(input, errorEl, isValid, 'Please select a service.');
    }
    case 'bookingDate': {
      const input = document.getElementById('bookingDate');
      const errorEl = document.getElementById('err-bookingDate');
      const value = input.value;
      if (!value) return setFieldState(input, errorEl, false, 'Please choose a date.');
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const chosen = new Date(`${value}T00:00:00`);
      const isValid = chosen >= today;
      return setFieldState(input, errorEl, isValid, 'Date cannot be in the past.');
    }
    case 'timeSlot': {
      const errorEl = document.getElementById('err-timeSlot');
      const isValid = !!selectedTimeSlot;
      if (isValid) {
        errorEl.textContent = '';
      } else {
        errorEl.textContent = 'Please select a time slot.';
      }
      return isValid;
    }
    default:
      return true;
  }
}

// Validates every field in the booking form; used on submit.
function validateBookingForm() {
  const fields = ['fullName', 'phone', 'email', 'serviceSelect', 'bookingDate', 'timeSlot'];
  const results = fields.map(validateField);
  return results.every(Boolean);
}

// Attaches blur + input listeners for real-time inline validation.
function initBookingValidation() {
  const fieldIds = ['fullName', 'phone', 'email', 'serviceSelect', 'bookingDate'];
  fieldIds.forEach((id) => {
    const el = document.getElementById(id);
    el.addEventListener('blur', () => validateField(id));
    el.addEventListener('input', () => {
      if (el.classList.contains('invalid')) validateField(id);
      updateSummary();
    });
    el.addEventListener('change', () => {
      if (id === 'bookingDate') {
        selectedTimeSlot = null;
        renderTimeSlots();
      }
      updateSummary();
    });
  });
}

/* ---------- Live Booking Summary ---------- */

// Recomputes and redisplays the live booking summary panel based on current form values.
function updateSummary() {
  const serviceId = Number(document.getElementById('serviceSelect').value) || null;
  const service = services.find((s) => s.id === serviceId);
  const dateValue = document.getElementById('bookingDate').value;

  document.getElementById('sum-service').textContent = service ? service.name : '—';
  document.getElementById('sum-duration').textContent = service ? formatDuration(service.duration) : '—';
  document.getElementById('sum-date').textContent = dateValue ? formatDate(dateValue) : '—';
  document.getElementById('sum-time').textContent = selectedTimeSlot || '—';
  document.getElementById('sum-total').textContent = service ? `$${service.price}` : '$0';
}

/* ---------- Booking Submission ---------- */

// Handles booking form submission: validates, checks conflicts, creates booking, shows confirmation.
function handleBookingSubmit(event) {
  event.preventDefault();

  const isFormValid = validateBookingForm();
  if (!isFormValid) {
    showToast('Please fix the highlighted errors before submitting.');
    return;
  }

  const dateValue = document.getElementById('bookingDate').value;
  const doubleBooked = bookings.some((b) => b.date === dateValue && b.time === selectedTimeSlot);
  if (doubleBooked) {
    document.getElementById('err-timeSlot').textContent = 'That time slot is already booked. Please choose another.';
    return;
  }

  const serviceId = Number(document.getElementById('serviceSelect').value);
  const service = services.find((s) => s.id === serviceId);

  const booking = {
    reference: generateBookingReference(),
    name: document.getElementById('fullName').value.trim(),
    phone: document.getElementById('phone').value.trim(),
    email: document.getElementById('email').value.trim(),
    serviceId: service.id,
    serviceName: service.name,
    duration: service.duration,
    price: service.price,
    date: dateValue,
    time: selectedTimeSlot,
    notes: document.getElementById('notes').value.trim(),
  };

  bookings.push(booking);
  submitBookingToNetlify(booking);
  showConfirmation(booking);
  renderBookingsList();
  showToast(`Booking confirmed! Reference ${booking.reference}`);
}

// Sends the booking to Netlify Forms so the business owner can see it in the Netlify dashboard.
// Fails silently when not running on Netlify (e.g. opening index.html directly) since there's
// no submission endpoint in that case — the local booking flow above still works either way.
function submitBookingToNetlify(booking) {
  if (window.location.protocol === 'file:') return;

  const payload = new URLSearchParams({
    'form-name': 'booking',
    reference: booking.reference,
    fullName: booking.name,
    phone: booking.phone,
    email: booking.email,
    serviceSelect: booking.serviceName,
    bookingDate: booking.date,
    timeSlot: booking.time,
    notes: booking.notes,
  });

  fetch('/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: payload.toString(),
  }).catch(() => {
    /* Not deployed on Netlify (e.g. local file), or offline — ignore. */
  });
}

// Displays the confirmation card in place of the booking form.
function showConfirmation(booking) {
  document.getElementById('bookingForm').classList.add('hidden');
  document.getElementById('bookingSummary').classList.add('hidden');

  document.getElementById('conf-ref').textContent = booking.reference;
  document.getElementById('conf-name').textContent = booking.name;
  document.getElementById('conf-service').textContent = booking.serviceName;
  document.getElementById('conf-duration').textContent = formatDuration(booking.duration);
  document.getElementById('conf-date').textContent = formatDate(booking.date);
  document.getElementById('conf-time').textContent = booking.time;
  document.getElementById('conf-phone').textContent = booking.phone;
  document.getElementById('conf-email').textContent = booking.email;
  document.getElementById('conf-total').textContent = `$${booking.price}`;

  document.getElementById('confirmationCard').classList.remove('hidden');
}

// Resets the booking form and returns the user to a blank booking state.
function resetBookingForm() {
  const form = document.getElementById('bookingForm');
  form.reset();
  selectedTimeSlot = null;
  document.getElementById('timeSlotInput').value = '';

  form.querySelectorAll('input, select, textarea').forEach((el) => {
    el.classList.remove('valid', 'invalid');
  });
  form.querySelectorAll('.error-msg').forEach((el) => { el.textContent = ''; });

  renderTimeSlots();
  updateSummary();

  document.getElementById('confirmationCard').classList.add('hidden');
  form.classList.remove('hidden');
  document.getElementById('bookingSummary').classList.remove('hidden');
}

/* ---------- My Bookings ---------- */

// Renders the "My Bookings" list from the in-memory bookings array.
function renderBookingsList() {
  const list = document.getElementById('bookingsList');
  const emptyState = document.getElementById('bookingsEmptyState');
  list.innerHTML = '';

  if (bookings.length === 0) {
    list.appendChild(emptyState);
    return;
  }

  bookings.forEach((booking) => {
    const item = document.createElement('div');
    item.className = 'booking-item';
    item.innerHTML = `
      <div>
        <div class="booking-ref">${booking.reference}</div>
        <div class="booking-details">${booking.serviceName} &middot; ${formatDate(booking.date)} at ${booking.time}</div>
      </div>
      <button type="button" class="cancel-btn" data-ref="${booking.reference}">Cancel</button>
    `;
    list.appendChild(item);
  });
}

// Cancels a booking by reference, removing it from state and re-rendering.
function cancelBooking(reference) {
  const index = bookings.findIndex((b) => b.reference === reference);
  if (index === -1) return;
  bookings.splice(index, 1);
  renderBookingsList();
  renderTimeSlots();
  showToast('Booking cancelled.');
}

function initBookingsList() {
  document.getElementById('bookingsList').addEventListener('click', (event) => {
    const btn = event.target.closest('.cancel-btn');
    if (!btn) return;
    cancelBooking(btn.dataset.ref);
  });
}

/* ---------- Contact Form ---------- */

// Validates a single contact-form field.
function validateContactField(fieldName) {
  switch (fieldName) {
    case 'contactName': {
      const input = document.getElementById('contactName');
      const errorEl = document.getElementById('err-contactName');
      const isValid = input.value.trim().length >= 2;
      return setFieldState(input, errorEl, isValid, 'Please enter your name.');
    }
    case 'contactEmail': {
      const input = document.getElementById('contactEmail');
      const errorEl = document.getElementById('err-contactEmail');
      const isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim());
      return setFieldState(input, errorEl, isValid, 'Enter a valid email address.');
    }
    case 'contactMessage': {
      const input = document.getElementById('contactMessage');
      const errorEl = document.getElementById('err-contactMessage');
      const isValid = input.value.trim().length >= 10;
      return setFieldState(input, errorEl, isValid, 'Message must be at least 10 characters.');
    }
    default:
      return true;
  }
}

function initContactForm() {
  const form = document.getElementById('contactForm');
  const fieldIds = ['contactName', 'contactEmail', 'contactMessage'];

  fieldIds.forEach((id) => {
    const el = document.getElementById(id);
    el.addEventListener('blur', () => validateContactField(id));
    el.addEventListener('input', () => {
      if (el.classList.contains('invalid')) validateContactField(id);
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const isValid = fieldIds.map(validateContactField).every(Boolean);
    if (!isValid) {
      showToast('Please fix the highlighted errors before sending.');
      return;
    }
    showToast('Message sent! We will get back to you soon.');
    form.reset();
    fieldIds.forEach((id) => document.getElementById(id).classList.remove('valid', 'invalid'));
  });
}

/* ---------- Navigation ---------- */

// Wires up the mobile hamburger menu toggle.
function initHamburgerMenu() {
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const nav = document.getElementById('primaryNav');

  hamburgerBtn.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    hamburgerBtn.classList.toggle('open', isOpen);
    hamburgerBtn.setAttribute('aria-expanded', String(isOpen));
  });

  nav.querySelectorAll('.nav-link').forEach((link) => {
    link.addEventListener('click', () => {
      nav.classList.remove('open');
      hamburgerBtn.classList.remove('open');
      hamburgerBtn.setAttribute('aria-expanded', 'false');
    });
  });
}

// Hero "Book Now" button scrolls smoothly to the booking form.
function initHeroBookButton() {
  document.getElementById('heroBookBtn').addEventListener('click', () => {
    document.getElementById('book').scrollIntoView({ behavior: 'smooth' });
  });
}

/* ---------- Scroll-triggered Animations ---------- */

// Observes elements with the .fade-in class and reveals them as they enter the viewport.
function initFadeInAnimations() {
  const targets = document.querySelectorAll('.fade-in');
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );
  targets.forEach((target) => observer.observe(target));
}

/* ---------- Init ---------- */

// Sets the minimum selectable date on the date input to today (blocks past dates natively too).
function initDateInputMin() {
  const dateInput = document.getElementById('bookingDate');
  const today = new Date();
  const iso = today.toISOString().split('T')[0];
  dateInput.min = iso;
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('currentYear').textContent = new Date().getFullYear();

  renderServices();
  populateServiceDropdown();
  renderTimeSlots();
  initDateInputMin();

  initFilterBar();
  initServiceSelection();
  initBookingValidation();
  initBookingsList();
  initContactForm();
  initHamburgerMenu();
  initHeroBookButton();
  initFadeInAnimations();

  document.getElementById('bookingForm').addEventListener('submit', handleBookingSubmit);
  document.getElementById('makeAnotherBtn').addEventListener('click', resetBookingForm);

  updateSummary();
});
